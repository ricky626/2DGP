import game_framework
import random

from My_pico2d import *

name = "Hero"

hero = None

class Hero:

    def __init__(self):

        pass

    def update(self):
        pass

    def draw(self):
        pass
    pass
